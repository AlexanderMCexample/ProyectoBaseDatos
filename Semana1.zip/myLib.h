#include "myLib.cpp"



/*
void variables_rango(int &n,int &k,int mayor, int menor);
void variables_rango(int &n, int mayor, int menor);

void multiplos_k(int n,int k);
void taches(int n);
void escalera(int n);



void triangulo_segun_angulos(float x,float y,float z);
void triangulo_segun_longitud(int x,int y,int z);
void triangulo (int x, int y, int z);
*/